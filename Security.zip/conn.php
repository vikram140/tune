<?php
$servername = "localhost";
$username = "u124652540_mcafeeb22";
$password = "?5M8V!hC";
$dbname = "u124652540_mcafeeb2";
// Create connection
$conn = mysqli_connect ($servername, $username, $password, $dbname);

// Check connection
if ($conn) 
{
    echo"";
} 

?>


