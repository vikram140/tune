<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="form_css.css">
	<link rel="stylesheet" type="text/css" href="form_css2.css">
	<link rel="stylesheet" type="text/css" href="form_css3.css">
</head>
<style type="text/css">
	
</style>

<body style="background-color: #dbdbdb">
	


<div class="container pt-5 pb-5" style="background-color: #dbdbdb">
	
	<h2 class="green" style="text-align: center; margin-bottom: 0; padding-bottom: 0; font-size: 26px;font-weight: bold">Thanks! Your antivirus subscription has been registered</h2>
	
	<h2 class="green" style="text-align: center; margin-top: 0; font-size: 26px;font-weight: bold">Next steps- Call (213)-205-4479 to instantly  Activate Your McAfee License</h2>
		
	<div class="t-box" style="background-color: #dbdbdb">
		<div class="gs">
			<div class="call">
				<img src="https://lp44.brilfoc.club/www/wp-content/themes/mcafeerenewal/images/phone.png" style="margin-right: 10px;"><span>(213)-205-4479 Free Help</span>
			</div>
			
			<p>
				Call number above to instantly download and install your active subscription on your device. Remember your subscription covers multiple devices. We will install antivirus protection on multiple devices and get it running. <b>100% Free</b>
			</p>
			
			<p>
				<b>Please note: You have to setup antivirus on your computer to block popups and delete virus infections.</b>
			</p>
		</div>
	</div>
	
	<div class="t-box" style="background-color: #dbdbdb">
		<div class="gs">
			<h2 class="green">For Assisted Installation (Recommended)</h2>
			
			<p>
				Our experienced techs can help you install antivirus and configure it as your your hardware and software configuration. Just call our toll free number now!			</p>
			
			<h3><b>(213)-205-4479</b></h3>
			
			<p>
				Our expert technicians will access your computer 100% securely and activate your antivirus protection and remove detected virus infections for you. call us now at our toll free number <b>(213)-205-4479</b>
			</p>
			
			<p><b>We will install Firewall and Antivirus protection and get it working <span class="blue">100% free</span></b></p>
		</div>
	</div>
	
	<div class="t-box" style="background-color: #dbdbdb">
		<div class="gs">
			<h2>For manual installation (Not Recommended)</h2>
			
			<ol style="margin-left: 15px;">
				<li>Download Mcafee Total Protection Setup</li>
				<li>Install the program</li>
				<li>Enter 25 Digit License key</li>
				<li>And activate.</li>
			</ol>
			
			<p><span style="color: #ff0000;"><strong>Sounds complicated?</strong></span>, Call</p>
			
			<h3><strong>(213)-205-4479</strong></h3>
			
			<p>Our expert technicians will access your computer 100% securely and activate your antivirus protection and remove detected virus infections for you. call us now at our toll free number <strong>(213)-205-4479<br> </strong></p>
			
			<p><strong>We will install Firewall and Antivirus protection and get it working 100% free</strong></p>
		<!-- 
			<a href="https://support.me/"><img src="https://lp44.brilfoc.club/www/wp-content/themes/mcafeerenewal/images/plus.png" class="plus"></a> -->


			<a href="#"><img src="https://lp44.brilfoc.club/www/wp-content/themes/mcafeerenewal/images/plus.png" class="plus"></a>
		</div>
	</div>

</div>

<script type="text/javascript" src="https://lp44.brilfoc.club/www/wp-content/themes/mcafeerenewal/js/bootstrap.min.js?ver=1.1" id="bootstrap-js"></script>
<script type="text/javascript" src="https://lp44.brilfoc.club/www/wp-content/themes/mcafeerenewal/js/lity.js?ver=1.1" id="lity-js"></script>
<script type="text/javascript" src="https://lp44.brilfoc.club/www/wp-includes/js/wp-embed.min.js?ver=5.7" id="wp-embed-js"></script>





</body>

</html>