<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="form_css.css">
	<link rel="stylesheet" type="text/css" href="form_css2.css">
	<link rel="stylesheet" type="text/css" href="form_css3.css">
</head>
<style type="text/css">
	
</style>

<body>
	


	<div class="container-fluid">

		<div class="container-fixed">

			<h2 class="green" style="font-weight: bolder;">Thank You for Register with Us !</h2>


			

			<img class="footer-logo" src="images/mcafee2.png" alt="" width="112" border="0">

		</div>

	</div>







</body>

</html>